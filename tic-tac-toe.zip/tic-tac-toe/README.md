# Tic Tac Toe

A Pen created on CodePen.io. Original URL: [https://codepen.io/iamrubberducky/pen/XjLGKv](https://codepen.io/iamrubberducky/pen/XjLGKv).

A little experiment in Collab Mode. Built together with @JonasKuiler to explain some basic Vue.js stuff